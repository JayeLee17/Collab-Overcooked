# Scheduler Slot Rebalancing Report

- Generated at: `2026-04-21T14:29:41`
- Train input rows: `903`
- Train output rows: `1357`
- Wash extra copies: `15`
- Slot-hard extra copies: `1`

## Train Distribution Before

- slot_easy: `464`
- slot_hard: `439`
- wash_negative: `902`
- wash_positive: `1`

## Train Distribution After

- slot_easy: `464`
- slot_hard: `893`
- wash_negative: `1340`
- wash_positive: `17`

## Added Rows

- extra_rows_added: `454`
- extra_slot_hard_rows_added: `454`
- extra_wash_positive_rows_added: `16`
- slot_hard_rows: `439`
- wash_positive_rows: `1`
