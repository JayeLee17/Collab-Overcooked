#!/usr/bin/env python3
"""
Rebalance slot-augmented scheduler SFT data without recollecting new samples.

Current goal:
- oversample rare wash-positive rows
- moderately oversample slot-hard rows
- keep val/test unchanged
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple


DEFAULT_TRAIN = Path(
    "results/scheduler_sft_collection/datasets/final_clean_v4_slot_augmented/train_scheduler_final_slot_augmented.jsonl"
)
DEFAULT_VAL = Path(
    "results/scheduler_sft_collection/datasets/final_clean_v4_slot_augmented/val_scheduler_final_slot_augmented.jsonl"
)
DEFAULT_TEST = Path(
    "results/scheduler_sft_collection/datasets/final_clean_v4_slot_augmented/test_scheduler_final_slot_augmented.jsonl"
)
DEFAULT_OUTPUT_DIR = Path(
    "results/scheduler_sft_collection/datasets/final_clean_v5_slot_rebalanced"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rebalance slot-augmented scheduler SFT dataset."
    )
    parser.add_argument("--train-data", type=Path, default=DEFAULT_TRAIN)
    parser.add_argument("--val-data", type=Path, default=DEFAULT_VAL)
    parser.add_argument("--test-data", type=Path, default=DEFAULT_TEST)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument(
        "--wash-extra-copies",
        type=int,
        default=15,
        help="Additional copies for each wash-positive train sample.",
    )
    parser.add_argument(
        "--slot-hard-extra-copies",
        type=int,
        default=1,
        help="Additional copies for each slot-hard train sample.",
    )
    return parser.parse_args()


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: Iterable[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")


def parse_response(response_text: str) -> Dict[str, Any]:
    return json.loads(response_text)


def is_wash_positive(response_obj: Dict[str, Any]) -> bool:
    return response_obj.get("wash_assignment") is not None


def is_slot_hard(response_obj: Dict[str, Any]) -> bool:
    slots = response_obj.get("selected_slots") or []
    if not isinstance(slots, list):
        return False
    kinds = {str(item.get("kind")) for item in slots if isinstance(item, dict)}
    return len(slots) >= 3 or ("keep" in kinds and "new" in kinds)


def classify_row(row: Dict[str, Any]) -> Dict[str, bool]:
    response_obj = parse_response(row["response"])
    return {
        "wash_positive": is_wash_positive(response_obj),
        "slot_hard": is_slot_hard(response_obj),
    }


def summarize_rows(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    counter: Counter = Counter()
    for row in rows:
        flags = classify_row(row)
        if flags["wash_positive"]:
            counter["wash_positive"] += 1
        else:
            counter["wash_negative"] += 1
        if flags["slot_hard"]:
            counter["slot_hard"] += 1
        else:
            counter["slot_easy"] += 1
    return dict(sorted(counter.items()))


def rebalance_train_rows(
    rows: List[Dict[str, Any]],
    *,
    wash_extra_copies: int,
    slot_hard_extra_copies: int,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    output_rows: List[Dict[str, Any]] = list(rows)
    counters: Counter = Counter()

    for row_index, row in enumerate(rows):
        flags = classify_row(row)
        extra_copies = 0
        reasons: List[str] = []

        if flags["slot_hard"]:
            extra_copies += max(0, slot_hard_extra_copies)
            if slot_hard_extra_copies > 0:
                reasons.append("slot_hard")
                counters["slot_hard_rows"] += 1
        if flags["wash_positive"]:
            extra_copies += max(0, wash_extra_copies)
            if wash_extra_copies > 0:
                reasons.append("wash_positive")
                counters["wash_positive_rows"] += 1

        for copy_idx in range(extra_copies):
            clone = deepcopy(row)
            meta = deepcopy(clone.get("meta") or {})
            meta["rebalanced"] = True
            meta["rebalanced_from_row_index"] = row_index
            meta["rebalanced_reasons"] = reasons
            meta["rebalanced_copy_index"] = copy_idx + 1
            clone["meta"] = meta
            output_rows.append(clone)
            counters["extra_rows_added"] += 1
            if flags["slot_hard"]:
                counters["extra_slot_hard_rows_added"] += 1
            if flags["wash_positive"]:
                counters["extra_wash_positive_rows_added"] += 1

    return output_rows, dict(sorted(counters.items()))


def write_report(output_dir: Path, report: Dict[str, Any]) -> None:
    (output_dir / "rebalancing_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    lines = [
        "# Scheduler Slot Rebalancing Report",
        "",
        f"- Generated at: `{report['generated_at']}`",
        f"- Train input rows: `{report['train_input_rows']}`",
        f"- Train output rows: `{report['train_output_rows']}`",
        f"- Wash extra copies: `{report['settings']['wash_extra_copies']}`",
        f"- Slot-hard extra copies: `{report['settings']['slot_hard_extra_copies']}`",
        "",
        "## Train Distribution Before",
        "",
    ]
    for key, value in report["train_distribution_before"].items():
        lines.append(f"- {key}: `{value}`")
    lines.extend(["", "## Train Distribution After", ""])
    for key, value in report["train_distribution_after"].items():
        lines.append(f"- {key}: `{value}`")
    lines.extend(["", "## Added Rows", ""])
    for key, value in report["augmentation_counts"].items():
        lines.append(f"- {key}: `{value}`")

    (output_dir / "rebalancing_report.md").write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    train_rows = load_jsonl(args.train_data)
    val_rows = load_jsonl(args.val_data)
    test_rows = load_jsonl(args.test_data)

    train_distribution_before = summarize_rows(train_rows)
    train_output, augmentation_counts = rebalance_train_rows(
        train_rows,
        wash_extra_copies=args.wash_extra_copies,
        slot_hard_extra_copies=args.slot_hard_extra_copies,
    )
    train_distribution_after = summarize_rows(train_output)

    write_jsonl(
        output_dir / "train_scheduler_final_slot_rebalanced.jsonl",
        train_output,
    )
    write_jsonl(
        output_dir / "val_scheduler_final_slot_rebalanced.jsonl",
        val_rows,
    )
    write_jsonl(
        output_dir / "test_scheduler_final_slot_rebalanced.jsonl",
        test_rows,
    )

    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "input_files": {
            "train": str(args.train_data),
            "val": str(args.val_data),
            "test": str(args.test_data),
        },
        "settings": {
            "wash_extra_copies": args.wash_extra_copies,
            "slot_hard_extra_copies": args.slot_hard_extra_copies,
        },
        "train_input_rows": len(train_rows),
        "train_output_rows": len(train_output),
        "val_rows": len(val_rows),
        "test_rows": len(test_rows),
        "train_distribution_before": train_distribution_before,
        "train_distribution_after": train_distribution_after,
        "augmentation_counts": augmentation_counts,
    }
    write_report(output_dir, report)

    print(f"train_input={len(train_rows)}")
    print(f"train_output={len(train_output)}")
    print(f"val_rows={len(val_rows)}")
    print(f"test_rows={len(test_rows)}")
    print(f"output_dir={output_dir}")


if __name__ == "__main__":
    main()
