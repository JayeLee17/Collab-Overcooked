# Scheduler SFT Dataset Cleaning Report

## Summary

- Generated at: `2026-04-21T01:31:14`
- Train input: `814`
- Train output: `903`
- Val input: `93`
- Val output: `93`
- Removed samples: `0`
- Rewritten samples: `907`
- Train duplicate rows removed: `0`
- Train oversampled rows added: `89`

## Settings

- oversample_multi_candidate: `2.0`
- downsample_simple_duplicates: `0.8`
- freeze_test: `True`
- skip_val_cleaning: `False`
- keep_invalid: `False`

## Train Sample Types

- keep_assignment: `567`
- mixed_assignment: `157`
- multi_candidate_assignment: `178`
- wash_assignment: `1`

## Train Issues

- none

## Val Issues

- none
