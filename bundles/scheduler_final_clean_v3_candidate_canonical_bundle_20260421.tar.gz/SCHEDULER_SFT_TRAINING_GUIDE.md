# 调度器 SFT 训练指南

日期：2026-04-20

## 1. 文档目标

本文档用于同步维护当前项目中“全局调度器 SFT”相关工作的实践方案、论文写作口径与阶段进度。

当前这份指南不再以“长期持续扩采”为主线，而是转为服务以下三个明确目标：

1. 基于当前已经收集到的约 `1000` 条高质量调度样本，形成毕设可用的最终版 SFT 数据集
2. 基于 `Qwen3.5-0.8B` 完成轻量调度器的监督微调与离线评估
3. 将数据集构建、训练设置、评测方法和阶段进度整理为可直接支撑论文第四章写作的实验材料

因此，本文档既是训练指南，也是当前阶段的实验设计备忘录。

## 2. 当前研究定位

本阶段 SFT 的研究对象是“全局调度器”，不是底层 Chef / Assistant / Dishwasher 的动作模仿模型。

模型需要学习的是：

1. 读取当前多智能体协作状态
2. 识别任务池状态、主体状态和资源状态
3. 在调度触发时做出结构化的任务分配或维护决策
4. 输出可解析、可执行、可评估的调度结果

结合当前毕设主线，调度器 SFT 的定位应明确为：

1. 轻量调度器的可行性验证实验
2. 基于真实 teacher 调度日志的小规模监督微调实验
3. 为后续替代高成本 teacher 调度器提供初步路径

这一部分不追求训练最强模型，而是验证“真实日志 + 小规模数据 + 轻量模型”是否能够形成一个初步可用的全局调度器。

## 3. 当前阶段的固定实验设定

为了保证数据质量和实验可解释性，当前 SFT 实验继续使用相对稳定、变量较少的设定。

### 3.1 固定地图

当前统一使用：

- `dependencies/overcooked_ai/overcooked_ai_py/data/layouts/multi_agent_map.layout`

### 3.2 teacher 调度器

当前 teacher 调度器来源为：

1. 运行在 LLM Scheduler 模式下的真实调度器
2. teacher 模型采用 `qwen3.5-plus`

### 3.3 当前任务池范围

当前主要采样范围为 level 1 的 5 个任务：

1. `baked_bell_pepper`
2. `baked_sweet_potato`
3. `boiled_egg`
4. `boiled_mushroom`
5. `boiled_sweet_potato`

前期 round 1 已基于这 5 个任务完成两两组合覆盖。  
当前最终版数据集 `999` 条样本，也主要建立在这一受控任务空间上。

### 3.4 单局采样方式

当前采集设定保持为：

1. 每局默认选择 `2` 个任务进入任务池
2. 任务组合优先采用均衡轮转或覆盖优先策略
3. 每个调度触发点保存一条 scheduler 样本

这样做的原因是：

1. 任务结构相对稳定，便于学习基本调度规律
2. 样本之间具有可比性，便于后续分析
3. 有利于控制变量，支撑毕设阶段的可行性验证

## 4. 当前项目进度同步

截至 `2026-04-20`，调度器 SFT 相关工作已完成以下关键节点：

1. 已完成 scheduler 输入输出日志补充
2. 已完成 scheduler 数据导出脚本编写
3. 已完成 round 1 数据统计、切分和训练包整理
4. 已在服务器上完成第一轮 `Qwen3.5-0.8B` LoRA SFT 训练
5. 已补充离线评估脚本，可输出 `summary.json`、`per_sample_report.csv` 等结果
6. 当前已进入“最终版数据集固化 + 第二轮或最终轮训练与评测”阶段

round 1 的已知里程碑如下：

1. 使用 level 1 的 5 个任务完成 `10` 组 pair 覆盖
2. 在 `latest per pair` 口径下得到 `279` 条可导出 scheduler 样本
3. 按 episode 切分得到：
4. train：`195`
5. dev：`28`
6. test：`56`
7. 第一轮训练输出目录：
8. `/work/lijiayi/sft_runs/scheduler_round1_qwen35_08b/20260417-193249/`
9. 当前已确认生成可用 LoRA adapter 和训练指标图

目前最新阶段性判断是：

1. round 1 已完成“链路跑通”目标
2. 当前最终版数据集已经冻结完成，共 `999` 条可导出 scheduler 样本
3. 下一步重点不应再是盲目扩采，而应转向“最终数据集冻结、最终训练、统一评测和论文写作”

当前 final split 已实际生成，结果如下：

1. source episodes：`39`
2. all samples：`999`
3. train：`31` 个 episode，`814` 条样本
4. val：`4` 个 episode，`93` 条样本
5. test：`4` 个 episode，`92` 条样本
6. 输出目录：`results/scheduler_sft_collection/datasets/final/`
7. 关键文件：
8. `train_scheduler_final.jsonl`
9. `val_scheduler_final.jsonl`
10. `test_scheduler_final.jsonl`
11. `all_scheduler_final.jsonl`
12. `final_split_manifest.csv`
13. `final_split_summary.md`

## 5. 与论文第四章目录的对应关系

为了便于论文写作，当前调度器 SFT 相关内容建议按第四章目录进行组织。

### 5.1 对应 4.3.3 调度器 SFT 实验设计

这一小节应重点回答以下问题：

1. 为什么要做调度器 SFT
2. 数据来自哪里
3. 为什么选 `Qwen3.5-0.8B`
4. 为什么约 `1000` 条数据仍然足以做可行性验证
5. 训练和对比实验如何设计

推荐写作口径为：

1. 本实验不是训练通用决策大模型
2. 本实验旨在验证轻量模型是否能够从真实调度日志中学习基本调度规律
3. 本实验属于“小规模高质量数据下的轻量调度器可行性验证”

### 5.2 对应 4.4 评价指标设计

这一节建议围绕“离线结构化评测 + 在线回放验证”展开。

离线指标重点包括：

1. `teacher_forcing_loss`
2. `teacher_forcing_perplexity`
3. `json_parse_pass_rate`
4. `required_keys_pass_rate`
5. `candidate_ids_exact_match_rate`
6. `wash_assignment_exact_match_rate`
7. `exact_json_match_rate`
8. `notes_nonempty_rate`

在线指标重点包括：

1. `Finished Tasks`
2. `Score`
3. `Score / Step`
4. `Blocked / Timeout Count`
5. 调度稳定性与典型错误行为分析

### 5.3 对应 4.5 实验结果与分析

由于第四章目录中目前只列出：

1. `4.5.1 全局调度器对比实验`
2. `4.5.2 A2A 协议 case study`

如果最终目录不单独新增“SFT 实验结果分析”小节，则建议将调度器 SFT 结果作为：

1. `4.5` 中的补充实验结果段落
2. 或者并入 `4.3.3` 之后的过渡说明

更稳妥的写法是：

1. 在 `4.3.3` 中写清实验设计
2. 在 `4.5` 中用一个独立自然段或小标题补充 SFT 的离线评测结果与初步在线回放结果

## 6. 最终版 SFT 数据集设计

考虑时间安排与当前进度，现阶段建议将“约 `1000` 条样本”定义为毕设阶段的正式版调度器 SFT 数据集。

这里的重点不是继续追求更大规模，而是把当前数据集设计得足够清楚、可复现、可分析。

### 6.1 数据来源

当前最终版数据集的样本来源为：

1. `LLM Scheduler` 模式下的真实运行日志
2. teacher 调度器使用 `qwen3.5-plus`
3. 采集环境固定为 `multi_agent_map`
4. 任务空间以 level 1 的 5 个任务两两组合为主

### 6.2 样本定义

对 scheduler SFT 来说，“一条样本”不是整局 episode，而是“一次调度触发点”。

每条样本至少包含三部分：

1. 调度输入
2. 调度输出
3. 元数据

### 6.3 建议保留的字段

调度输入建议保留：

1. 当前 timestep
2. 当前任务池状态
3. 各 agent 的角色、busy/idle、当前任务、当前动作
4. 资源状态和资源锁
5. clean dish / dirty dish 状态
6. 当前触发原因
7. 当前地图名
8. 当前任务组合
9. 当前 scheduler 模式

调度输出建议保留：

1. 候选主体选择结果
2. 任务分配结果
3. wash assignment
4. keep / protect / release 结果
5. 结构化 reason 或 notes

元数据建议保留：

1. run id
2. teacher 名称
3. scene 或任务组合标识
4. 当前样本是否可导出
5. 当前样本是否来自成功 episode

### 6.4 数据集划分建议

当前最终版数据集建议保持固定切分，不再频繁变化。

在总量约 `1000` 条的前提下，推荐两种可行方案：

1. `train 70% / val 10% / test 20%`
2. `train 80% / val 10% / test 10%`

对当前阶段更推荐第二种，即：

1. 训练集尽量扩大
2. 验证集保留必要调参能力
3. 测试集保持代表性即可

切分原则：

1. 尽量按 episode 或 pair 分层切分
2. 保证主要任务组合在 test 中有覆盖
3. test 集一旦确定，后续模型对比保持不变

当前已落实的最终切分即为：

1. train：`814`
2. val：`93`
3. test：`92`

最终切分脚本为：

1. `scripts/sft/prepare_scheduler_final_sft.py`

## 7. 最终版训练实验设计

### 7.1 实验目标

当前最终版训练实验应围绕三个问题展开：

1. 轻量模型能否从约 `1000` 条真实调度日志中学到基本调度格式与决策规律
2. SFT 后的模型能否在关键字段上优于未训练基线模型
3. SFT 后的模型能否在少量真实场景回放中表现出初步可用的调度能力

### 7.2 基座模型

当前固定使用：

1. `Qwen3.5-0.8B`

选择理由：

1. 参数规模较小，便于快速微调和验证
2. 与当前毕设算力条件匹配
3. 有利于体现“teacher 大模型 -> student 轻量模型”的路径

### 7.3 主实验对比

当前最推荐保留以下两类对比：

第一类：未训练基线 vs 最终 SFT 模型

1. `Base Qwen3.5-0.8B`
2. `Final SFT Qwen3.5-0.8B`

这一组是核心主对比，用于回答“SFT 是否有效”，也是当前阶段必须保留的一组对比。

第二类：阶段性 SFT vs 最终 SFT

1. `Round1 SFT`
2. `Final SFT`

这一组调整为备选补充对比。  
如果最终时间允许，可用于说明随着样本规模增加，模型调度能力是否进一步提升；如果时间紧张，则可只保留 `Base vs Final` 这一组主对比。

### 7.4 训练方式建议

当前仍建议采用 LoRA 方式训练。

建议保持与 round 1 接近的训练配置，避免在最终阶段同时改动过多变量：

1. epoch：`2-3`
2. learning rate：`2e-5` 左右
3. LoRA rank：`16`
4. LoRA alpha：`32`
5. LoRA dropout：`0.05`
6. max length：`2048`
7. per-device train batch size：`1`
8. gradient accumulation：`16`

当前最终实验的重点不是调很多超参，而是：

1. 保持训练流程稳定
2. 保证和 round 1 可比
3. 把“数据规模变化带来的提升”看清楚

## 8. 评测设计

### 8.1 离线结构化评测

离线评测是当前调度器 SFT 最重要的一部分，建议作为正式结果表的核心来源。

重点关注以下指标：

1. `json_parse_pass_rate`
2. `required_keys_pass_rate`
3. `candidate_ids_exact_match_rate`
4. `wash_assignment_exact_match_rate`
5. `teacher_forcing_loss`
6. `teacher_forcing_perplexity`

其中需要特别说明：

1. `exact_json_match_rate` 仅作为严格一致性辅助指标
2. 调度任务可能存在多个合理答案，因此不能只看 exact JSON match
3. 更应关注结构合法性和关键决策字段是否正确

### 8.2 小规模在线回放验证

在线验证不必追求大规模统计，只需选择少量代表性场景验证“初步可用性”。

推荐选择三类场景：

1. 简单场景：验证基本分配是否正确
2. 中等复杂场景：验证并发协作是否稳定
3. 含 wash 或资源瓶颈场景：验证维护类任务插入能力

推荐对比对象：

1. `Rule Scheduler`
2. `Base Qwen3.5-0.8B`
3. `Final SFT Qwen3.5-0.8B`

如果时间有限，至少保留：

1. `Rule Scheduler`
2. `Final SFT Scheduler`

## 9. 当前阶段最推荐的执行顺序

考虑到目前已经完成 `999` 条样本采集，当前最推荐执行顺序如下：

### 第一步：冻结最终数据集

1. 确认当前可导出样本总数：`999`
2. 将当前数据集固化为正式版本目录：`results/scheduler_sft_collection/datasets/final/`
3. 固定 train / val / test 切分：`814 / 93 / 92`
4. 不再边采边改 test 集

如需重新生成 final split，可使用：

```bash
python scripts/sft/prepare_scheduler_final_sft.py \
  --results-root results/scheduler_sft_collection/raw_runs \
  --output-dir results/scheduler_sft_collection/datasets/final
```

### 第二步：做最终版数据质量统计

重点检查：

1. 各 pair 的样本分布
2. 重复样本比例
3. 关键字段是否完整
4. 是否存在明显偏向单一简单场景的问题

### 第三步：进行最终版 SFT 训练

1. 保持与 round 1 接近的训练流程
2. 训练 `Final SFT Qwen3.5-0.8B`
3. 保存最终 adapter、训练曲线和训练参数

推荐直接使用的 final split 文件：

1. `results/scheduler_sft_collection/datasets/final/train_scheduler_final.jsonl`
2. `results/scheduler_sft_collection/datasets/final/val_scheduler_final.jsonl`
3. `results/scheduler_sft_collection/datasets/final/test_scheduler_final.jsonl`

### 第四步：统一离线评测

当前最推荐统一评测以下模型：

1. `Base`
2. `Final SFT`

如果时间允许，再补：

1. `Round1 SFT`

输出建议包括：

1. `summary.json`
2. `per_sample_report.csv`
3. 可用于论文表格的汇总 CSV 或 Markdown

### 第五步：做少量在线回放

1. 选 2 到 3 个代表场景
2. 观察任务完成数、得分、blocked count 和调度稳定性
3. 记录典型成功与失败案例，作为论文分析素材

### 当前最推荐的训练命令模板

```bash
python scripts/sft/train_qwen_sft.py \
  --train-data results/scheduler_sft_collection/datasets/final/train_scheduler_final.jsonl \
  --eval-data results/scheduler_sft_collection/datasets/final/val_scheduler_final.jsonl \
  --test-data results/scheduler_sft_collection/datasets/final/test_scheduler_final.jsonl \
  --model-name /path/to/Qwen3.5-0.8B \
  --output-dir runs/scheduler_final_qwen35_08b \
  --dataset-mode single \
  --single-target-name Scheduler \
  --epochs 3 \
  --per-device-train-batch-size 1 \
  --per-device-eval-batch-size 1 \
  --gradient-accumulation-steps 16 \
  --learning-rate 2e-5 \
  --max-length 2048 \
  --use-lora \
  --lora-r 16 \
  --lora-alpha 32 \
  --lora-dropout 0.05 \
  --bf16 \
  --plot-metrics
```

## 10. 当前阶段的核心判断

基于当前进度，现阶段不再建议把主要时间投入到无上限继续采集数据。

更合理的策略是：

1. 将约 `1000` 条样本作为毕设阶段的正式 SFT 数据集
2. 把实验定位为“小规模真实日志下的轻量调度器可行性验证”
3. 用“数据集统计 + 离线结构化评测 + 小规模在线回放”三部分支撑实验结论

一句话总结：

当前调度器 SFT 工作已经从“基础设施搭建阶段”进入“最终实验收口阶段”，下一步应以最终数据集冻结、最终模型训练、统一离线评测和少量在线验证为主，而不是继续无限扩采。
