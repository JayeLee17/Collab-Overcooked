# Candidate Consistency Audit

- Generated at: `2026-04-21T01:40:20`
- Train rows changed: `44` / `903`
- Train changed slots: `78`
- Val rows changed: `12` / `93`
- Val changed slots: `15`

## Train Top Replacements

- A1 -> A3 on `pot0`: `26`
- A4 -> A0 on `pot0`: `20`
- A0 -> A4 on `oven0`: `14`
- A3 -> A1 on `oven0`: `14`
- A1 -> A3 on `oven0`: `2`
- A0 -> A4 on `chopping_board0`: `2`

## Train Changed Role Counts

- chef: `36`
- assistant: `42`
