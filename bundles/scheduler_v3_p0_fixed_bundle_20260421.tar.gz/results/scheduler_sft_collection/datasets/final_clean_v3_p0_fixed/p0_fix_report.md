# Scheduler P0 Fix Report

- Generated at: `2026-04-21T23:42:07`
- Train order rewrites: `469`
- Train conflict group count: `1`
- Train conflict rows rewritten: `1`
- Test order rewrites: `0`
- Test conflict group count: `1`
- Test conflict rows rewritten: `1`

## Notes

- `candidate_order_rows_rewritten` means canonical sorting/formatting changes.
- `conflict_rows_rewritten` means the row label was replaced by the local majority label under the same semantic signature.

